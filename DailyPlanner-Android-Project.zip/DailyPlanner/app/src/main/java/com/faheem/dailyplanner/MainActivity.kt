package com.faheem.dailyplanner

import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat

private data class Task(val name:String, val time:String, val done:Boolean=false)

class MainActivity: ComponentActivity(){
 override fun onCreate(savedInstanceState: Bundle?){super.onCreate(savedInstanceState); createChannel(); setContent{DailyPlannerApp()}}
 private fun createChannel(){if(Build.VERSION.SDK_INT>=26){val c=NotificationChannel("planner","Daily Planner",NotificationManager.IMPORTANCE_HIGH); getSystemService(NotificationManager::class.java).createNotificationChannel(c)}}
}

@Composable fun DailyPlannerApp(){
 var logged by remember { mutableStateOf(false) }
 var email by remember { mutableStateOf("") }; var pass by remember { mutableStateOf("") }
 if(!logged){ LoginScreen(email,{email=it},pass,{pass=it}){logged=true}; return }
 var tasks by remember { mutableStateOf(listOf(Task("English — 30 minutes","06:30"),Task("HTML/CSS practice","08:00"),Task("JavaScript lesson","10:00"),Task("Exercise","17:00"),Task("Daily review","20:30"))) }
 var tab by remember{mutableStateOf(0)}
 Scaffold(bottomBar={NavigationBar{listOf("Dashboard","Today","Schedule").forEachIndexed{i,s->NavigationBarItem(i==tab,{tab=i},icon={},label={Text(s)})}}}){p->
  Box(Modifier.padding(p).padding(18.dp)){when(tab){0->Dashboard(tasks);1->Today(tasks){idx->tasks=tasks.mapIndexed{j,t->if(j==idx)t.copy(done=!t.done) else t}};2->Schedule(tasks)}}}
}

@Composable fun LoginScreen(email:String,onE:(String)->Unit,pass:String,onP:(String)->Unit,onLogin:()->Unit){Column(Modifier.fillMaxSize().padding(28.dp),verticalArrangement=Arrangement.Center){Text("Daily Planner",style=MaterialTheme.typography.headlineLarge);Text("Plan your day. Build your future.",modifier=Modifier.padding(bottom=24.dp));OutlinedTextField(email,onE,label={Text("Email")},modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(12.dp));OutlinedTextField(pass,onP,label={Text("Password")},modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(20.dp));Button(onClick=onLogin,modifier=Modifier.fillMaxWidth()){Text("Login")}}}
@Composable fun Dashboard(tasks:List<Task>){val done=tasks.count{it.done};val pct=if(tasks.isEmpty())0 else done*100/tasks.size;Column{Text("Good evening 👋",style=MaterialTheme.typography.headlineMedium);Text("Today's progress",modifier=Modifier.padding(top=18.dp));Text("$pct%",style=MaterialTheme.typography.displaySmall);LinearProgressIndicator(progress={pct/100f},modifier=Modifier.fillMaxWidth().padding(vertical=10.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Completed: $done");Text("Remaining: ${tasks.size-done}")};Spacer(Modifier.height(25.dp));Text("🔥 Keep your streak alive!",style=MaterialTheme.typography.titleLarge)}}
@Composable fun Today(tasks:List<Task>,toggle:(Int)->Unit){Column{Text("Today's Tasks",style=MaterialTheme.typography.headlineMedium);Spacer(Modifier.height(12.dp));LazyColumn{items(tasks.size){i->val t=tasks[i];Card(Modifier.fillMaxWidth().padding(vertical=5.dp),onClick={toggle(i)}){Row(Modifier.padding(16.dp).fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Column{Text(t.name,style=MaterialTheme.typography.titleMedium);Text(t.time)};Checkbox(t.done,{toggle(i)})}}}}}}
@Composable fun Schedule(tasks:List<Task>){Column{Text("Daily Schedule",style=MaterialTheme.typography.headlineMedium);Spacer(Modifier.height(12.dp));tasks.forEach{t->ListItem(headlineContent={Text(t.name)},supportingContent={Text(if(t.done)"Completed" else "Scheduled")},leadingContent={Text(t.time)})}}}
